# How to setup: 

### 1. Clone the repo

### 2.create python virtual environment: 
python -m venv CTRL_Venv

### 3.Activate venv: 
CTRL_Venv\Scripts\activate

note: Before activating venv, ensure you are in the right directory wheree venv is installed

### 4.Locate the directory of the app

### 5.Install required dependencies: 
pip install -r requirements.txt

### 6.run the api:
fastapi dev main.py 
